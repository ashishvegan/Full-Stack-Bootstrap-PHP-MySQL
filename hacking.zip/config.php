<?php
    error_reporting(0);
    $auth = mysqli_connect("localhost","root","","student_information");
    date_default_timezone_set("Asia/Kolkata");
    session_start();
?>